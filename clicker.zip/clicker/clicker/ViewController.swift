//
//  ViewController.swift
//  clicker
//
//  Created by Другов Родион on 31/05/2019.
//  Copyright © 2019 Другов Родион. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var numberLabel: UILabel!
    @IBOutlet weak var pressedButton: UIButton!
    @IBOutlet weak var trapTextField: UITextField!
    @IBOutlet weak var rateTextField: UITextField!
    @IBOutlet weak var cashLabel: UILabel!
    @IBOutlet weak var activationOutlet: UIButton!
    @IBOutlet weak var resumeGame: UIButton!
    @IBOutlet weak var informationButton: UIButton!
    
    var state = GameState()
    
    var isGameActivated = false {
        didSet {
            if isGameActivated == true {
                pressedButton.isEnabled = true
                informationButton.isEnabled = false
                state.cash -= state.rate
                cashLabel.text = String(state.cash)
            } else {
                pressedButton.isEnabled = false
            }
        }
    }
    
    var isRetryGame = false {
        didSet {
            if isRetryGame == true {
                state.clicks = 0
                
                state.randomNumbers.shuffle()
                
                resumeGame.isEnabled = false
                pressedButton.isEnabled = true
                informationButton.isEnabled = true
                
                numberLabel.text = String(state.clicks)
                trapTextField.text = ""
                rateTextField.text = ""
            } else {
                isRetryGame = false
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        cashLabel.text = String(state.cash)
        
        
        pressedButton.layer.cornerRadius = pressedButton.frame.width / 10

        state.randomNumbers.shuffle()
        
        addDoneButtonTo(rateTextField)
        addDoneButtonTo(trapTextField)
        
        resumeGame.isEnabled = false
        activationOutlet.isEnabled = false
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        print(cashLabel.text!)
        print(state.cash)
    }
    
    
    @objc func keyboardWillShow(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue {
            if self.view.frame.origin.y == 0 {
                self.view.frame.origin.y -= keyboardSize.height
            }
        }
    }
    
    @objc func keyboardWillHide(notification: NSNotification) {
        if self.view.frame.origin.y != 0 {
            self.view.frame.origin.y = 0
        }
    }
    
    @IBAction func retryFromGame(_ sender: UIButton) {
        isRetryGame = true
        isGameActivated = false
        
        trapTextField.isEnabled = true
        rateTextField.isEnabled = true
        
    }
    
    @IBAction func trapTF(_ sender: UITextField) {
        testForTextField()
    }
    
    @IBAction func rateTF(_ sender: UITextField) {
        testForTextField()
    }
    
    @IBAction func activationAction(_ sender: UIButton) {
        
        if state.rate > state.cash {
            let errorAlert = UIAlertController.init(title: "Ошибка", message: "У вас недостаточно средств", preferredStyle: .alert)
            let errorAlertAction = UIAlertAction.init(title: "Ок", style: .default)
            
            errorAlert.addAction(errorAlertAction)
            present(errorAlert, animated: true, completion: nil)
            
        } else if state.trap > 10 {
            
            let errorAlert = UIAlertController.init(title: "Ошибка", message: "Вы не можете поставить данное число, так как максимально число 10", preferredStyle: .alert)
            let errorAlertAction = UIAlertAction.init(title: "Ок", style: .default)
            
            errorAlert.addAction(errorAlertAction)
            present(errorAlert, animated: true, completion: nil)
            
        } else {
            
            isGameActivated = true
            activationOutlet.isEnabled = false
            trapTextField.isEnabled = false
            rateTextField.isEnabled = false
        }
    }
    
    
    
    @IBAction func clicker(_ sender: UIButton) {
        
        let stateClicks = state.clicks + 1
        
        if state.trap <= state.randomNumbers[0], stateClicks == state.trap{ //если цифра в ловушке меньше чем рандомное число то идем дальше
            
            let alertToWin = UIAlertController.init(title: "Победа!", message: "Вы выиграли, поздравляем!", preferredStyle: .alert)
            let alertAction = UIAlertAction.init(title: "Ок", style: .default)
            
            switch state.trap {
            case 1 : changeTrap(num: state.trap * state.rate)
            case 2 : changeTrap(num: state.rate * 1 / 5 + state.rate)
            case 3 : changeTrap(num: state.rate * 2 / 5 + state.rate)
            case 4 : changeTrap(num: state.rate * 4 / 5 + state.rate)
            case 5 : changeTrap(num: state.rate * 6 / 5 + state.rate)
            case 6, 7 : changeTrap(num: state.rate * 2 * (state.rate - 5))
                
            default : changeTrap(num: state.rate * state.trap + 10000)
            }
            
            resumeGame.isEnabled = true
            pressedButton.isEnabled = false
            
            alertToWin.addAction(alertAction)
            present(alertToWin, animated: true, completion: nil)
            
        }
        
        print("здесь твоя ловушка \(state.trap)")
        
        if state.clicks < 10 {
            state.clicks += 1
        }
        
        numberLabel.text = String(state.clicks)
        
        print(state.randomNumbers[0])
        
        if state.clicks == state.randomNumbers[0] {
            
            let alert = UIAlertController(title: "Вы проиграли!",
                                          message: "В следующий раз повезет, не сдавайтесь!.",
                                          preferredStyle: .alert)
            
            
            alert.addAction(UIAlertAction(title: "Закончить", style: .destructive, handler: { action in
                switch action.style{
                    
                case .default:
                    return
                case .cancel:
                    return
                    
                case .destructive:
                    
                    self.pressedButton.isEnabled = false
                    self.resumeGame.isEnabled = true
                    
                @unknown default:
                    return
                }}))
            
            self.present(alert, animated: true, completion: nil)
            
            return
            
        }
    }
    
    func testForTextField() {
        if rateTextField.text == "" || trapTextField.text == ""{
            activationOutlet.isEnabled = false
        } else {
            activationOutlet.isEnabled = true
        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == rateTextField {
            guard
                let rateString = textField.text,
                let rateCount = Int(rateString),
                rateCount > 0 else {
                    state.rate = 0
                    return
                    // show error
            }
            state.rate = rateCount
        } else if textField == trapTextField {
            guard
                let trapString = textField.text,
                let trapCount = Int(trapString),
                trapCount > 0 else {
                    state.trap = 0
                    return
                    // show error
            }
            state.trap = trapCount
        }
    }
    
    func changeTrap(num: Int) {
        state.cash += num
        cashLabel.text = String(state.cash)
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let text: String = textField.text ?? ""
        if text.isEmpty, string == "0" {
            return false
        }
        
        return true
    }
    
    // Скрытие клавиатуры по тапу за пределами Text View
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        
        view.endEditing(true) // Скрывает клавиатуру, вызванную для любого объекта
    }
    
    private func addDoneButtonTo(_ textField: UITextField) {
        
        let keyboardToolbar = UIToolbar()
        textField.inputAccessoryView = keyboardToolbar
        keyboardToolbar.sizeToFit()
        
        let doneButton = UIBarButtonItem(title:"Done",
                                         style: .done,
                                         target: self,
                                         action: #selector(didTapDone))
        
        let flexBarButton = UIBarButtonItem(barButtonSystemItem: .flexibleSpace,
                                            target: nil,
                                            action: nil)
        
        keyboardToolbar.items = [flexBarButton, doneButton]
    }
    
    @objc private func didTapDone() {
        view.endEditing(true)
    }
    
}

extension Int {
    var arc4random: Int{
        if self > 0 {
            return Int(arc4random_uniform(UInt32(self)))
        } else {
            return 0
        }
    }
}


