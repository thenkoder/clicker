//
//  GameState.swift
//  clicker
//
//  Created by Другов Родион on 01/06/2019.
//  Copyright © 2019 Другов Родион. All rights reserved.
//

import Foundation

struct GameState {
    var clicks = 0
    var trap = 0
    var rate = 0
    var cash = 1000
    
    var randomNumbers = [1, 1, 1, 1, 2, 2, 2, 2,
                         3, 4, 5, 6, 7, 8, 9, 10]
}
    
//    mutating func trapAndRate(newTrap: Int, newRate: Int)  {
//
//        trap = newTrap
//        rate = newRate
//
//        if trap <= r {
//
//        } else {
//
//        }
//    }
//
//    mutating func clickCount() -> Bool {
//
//        if trap != 0 && rate != 0{
//            clicks += 1
//        }
//
//        if clicks < trap {
//
//        }
//
//    }
//
//    mutating func newGame() {
//        r = randomNumber()
//        rate = 0
//        trap = 0
//        clicks = 0
//    }
//
//    mutating func randomNumber() -> Int {
//        randomNumbers.shuffle()
//        return randomNumbers[0]
//    }
    
//}
